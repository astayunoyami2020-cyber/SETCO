# SETCO Corporate Website

Official bilingual corporate website for **SETCO — Smart Economy for Trade and Import**.

The project follows the company-story and service structure requested for SETCO, with HTC presented as the only technology partner.

## Pages

- `/` — Homepage with SETCO story, business fields, achievements, HTC partnership and contact footer
- `/services` — HTC-only brand portfolio, distribution channels and after-sales services

Both pages support English and Arabic, responsive navigation, desktop and mobile layouts.

## Technology

- React 19
- Next.js 16
- TypeScript
- Vinext / Vite
- Tailwind CSS 4

## Run locally

Requirements: Node.js `22.13.0` or later.

```bash
npm install
npm run dev
```

Then open the local address shown in the terminal.

## Production build

```bash
npm run build
```

## Project structure

```text
app/
  page.tsx              Homepage
  services/page.tsx     Smart Devices & Accessories page
  globals.css           Shared responsive styling
  layout.tsx            Site metadata and layout
public/                 SETCO, HTC and website image assets
```

## Brand scope

HTC is the only partner and smartphone brand displayed in this version of the website.
