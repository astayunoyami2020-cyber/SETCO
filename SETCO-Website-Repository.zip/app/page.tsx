"use client";

import { useState } from "react";

const content = {
  en: {
    nav: [
      ["Homepage", "#top"],
      ["About SETCO", "#about"],
      ["Smart Devices & Accessories", "/services"],
      ["Solar Energy", "#fields"],
      ["E-Commerce", "#fields"],
      ["Contact", "#contact"],
    ],
    heroOverline: "SMART ECONOMY FOR TRADE AND IMPORT",
    hero: "WE BUILD SMARTER ROUTES BETWEEN GLOBAL TECHNOLOGY AND THE SAUDI MARKET",
    storyKicker: "ABOUT SETCO",
    storyTitle: "A Saudi story built on ambition, technology and trust.",
    story: [
      "SETCO — Smart Economy for Trade and Import — began in Jeddah with a clear belief: global technology deserves a stronger, more intelligent route into the Saudi market.",
      "What started as an ambition to connect trusted products with local demand has grown into a business shaped around smart devices, accessories, trade, e-commerce and practical energy solutions. SETCO combines market understanding, channel development and disciplined execution to move brands from opportunity to real market presence.",
      "Our partnership with HTC marks an important chapter in that story. It reflects our commitment to bringing respected technology closer to customers, strengthening retail access and building long-term value across Saudi Arabia.",
    ],
    fieldsKicker: "COMPANY FIELDS",
    fieldsIntro: "SETCO OPERATES ACROSS CONNECTED COMMERCIAL FIELDS",
    fields: [
      {
        title: "Smart Devices & Accessories",
        body: "SETCO develops the market for smart devices and accessories through focused distribution, retail execution and channel relationships across Saudi Arabia.",
        image: "/field-devices.jpg",
      },
      {
        title: "Solar Energy",
        body: "We help practical, dependable energy solutions reach businesses and customers through commercially grounded market pathways.",
        image: "/field-solar.jpg",
      },
      {
        title: "E-Commerce",
        body: "Our digital commerce approach connects products with broader customer segments and supports a faster, more accessible buying journey.",
        image: "/field-ecommerce.jpg",
      },
    ],
    milestonesKicker: "ACHIEVEMENTS & EVENTS",
    milestonesIntro: "A growing story of market development, brand building and connected execution.",
    milestones: [
      ["01", "HTC Partnership", "A defining partnership focused on developing HTC's presence and customer access in Saudi Arabia."],
      ["02", "Saudi Market Focus", "A Jeddah-based business built around local knowledge, commercial opportunity and long-term relationships."],
      ["03", "Connected Execution", "Trade planning, channel development, retail visibility and digital commerce working as one system."],
    ],
    partnerKicker: "OUR PARTNERS",
    builtWith: "BUILT IN PARTNERSHIP WITH",
    footerMenu: "MENU",
    footerTouch: "GET IN TOUCH",
    footerSocial: "STAY CONNECTED",
    location: "Jeddah, Saudi Arabia",
    enquiries: "Business & partnership enquiries",
    rights: "SETCO. ALL RIGHTS RESERVED",
  },
  ar: {
    nav: [
      ["الرئيسية", "#top"],
      ["عن سيتكو", "#about"],
      ["الأجهزة الذكية وملحقاتها", "/services"],
      ["الطاقة الشمسية", "#fields"],
      ["التجارة الإلكترونية", "#fields"],
      ["تواصل معنا", "#contact"],
    ],
    heroOverline: "سمارت إيكونومي للتجارة والاستيراد",
    hero: "نبني مسارات أذكى تربط التقنية العالمية بالسوق السعودي",
    storyKicker: "عن سيتكو",
    storyTitle: "قصة سعودية صنعتها الطموحات والتقنية والثقة.",
    story: [
      "بدأت سيتكو — سمارت إيكونومي للتجارة والاستيراد — رحلتها في جدة بإيمان واضح: التقنية العالمية تستحق طريقاً أقوى وأكثر ذكاءً إلى السوق السعودي.",
      "ما بدأ كطموح لربط المنتجات الموثوقة بالطلب المحلي تطور إلى شركة تعمل في الأجهزة الذكية وملحقاتها والتجارة والتجارة الإلكترونية وحلول الطاقة العملية. تجمع سيتكو بين فهم السوق وتطوير القنوات والتنفيذ المنضبط لتحويل الفرص إلى حضور حقيقي في السوق.",
      "تمثل شراكتنا مع HTC فصلاً مهماً في هذه القصة، وتعكس التزامنا بتقريب التقنية الموثوقة من العملاء وتعزيز حضورها في نقاط البيع وبناء قيمة مستدامة في المملكة العربية السعودية.",
    ],
    fieldsKicker: "مجالات الشركة",
    fieldsIntro: "تعمل سيتكو في مجالات تجارية مترابطة",
    fields: [
      {
        title: "الأجهزة الذكية وملحقاتها",
        body: "تطور سيتكو سوق الأجهزة الذكية وملحقاتها من خلال التوزيع المدروس والتنفيذ في نقاط البيع والعلاقات مع القنوات داخل المملكة.",
        image: "/field-devices.jpg",
      },
      {
        title: "الطاقة الشمسية",
        body: "نساعد حلول الطاقة العملية والموثوقة على الوصول إلى الشركات والعملاء عبر مسارات تجارية واضحة.",
        image: "/field-solar.jpg",
      },
      {
        title: "التجارة الإلكترونية",
        body: "تربط قنواتنا الرقمية المنتجات بشرائح أوسع من العملاء وتدعم رحلة شراء أسرع وأسهل.",
        image: "/field-ecommerce.jpg",
      },
    ],
    milestonesKicker: "الإنجازات والفعاليات",
    milestonesIntro: "قصة متنامية في تطوير الأسواق وبناء العلامات والتنفيذ المتكامل.",
    milestones: [
      ["01", "الشراكة مع HTC", "شراكة محورية تركز على تطوير حضور HTC وتسهيل وصول العملاء إليها في المملكة."],
      ["02", "تركيز على السوق السعودي", "شركة من جدة تقوم على فهم السوق والفرص التجارية وبناء العلاقات طويلة المدى."],
      ["03", "تنفيذ مترابط", "التخطيط التجاري وتطوير القنوات والحضور في نقاط البيع والتجارة الرقمية ضمن منظومة واحدة."],
    ],
    partnerKicker: "شركاؤنا",
    builtWith: "نبني المستقبل بالشراكة مع",
    footerMenu: "القائمة",
    footerTouch: "تواصل معنا",
    footerSocial: "تابعنا",
    location: "جدة، المملكة العربية السعودية",
    enquiries: "استفسارات الأعمال والشراكات",
    rights: "سيتكو. جميع الحقوق محفوظة",
  },
};

export default function Home() {
  const [language, setLanguage] = useState<"en" | "ar">("en");
  const [menuOpen, setMenuOpen] = useState(false);
  const copy = content[language];
  const isArabic = language === "ar";

  return (
    <main dir={isArabic ? "rtl" : "ltr"}>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="SETCO homepage">
          <img src="/setco-logo-transparent.png" alt="SETCO — Smart Economy for Trade and Import" />
        </a>

        <nav className={menuOpen ? "nav-links open" : "nav-links"} aria-label="Main navigation">
          {copy.nav.map(([label, href], index) => (
            <a className={index === 0 ? "active" : ""} key={`${label}-${index}`} href={href} onClick={() => setMenuOpen(false)}>
              {label}
            </a>
          ))}
        </nav>

        <div className="header-actions">
          <button className="language-toggle" onClick={() => setLanguage(isArabic ? "en" : "ar")}>
            {isArabic ? "EN" : "العربية"}
          </button>
          <button className="menu-toggle" aria-label="Toggle navigation" aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
            <span /><span /><span />
          </button>
        </div>
      </header>

      <section id="top" className="hero">
        <div className="hero-shape hero-shape-left" />
        <div className="hero-shape hero-shape-right" />
        <div className="hero-content">
          <p className="hero-overline">{copy.heroOverline}</p>
          <h1>{copy.hero}</h1>
          <a href="#about" className="scroll-cue" aria-label="Scroll to the SETCO story"><span>↓</span></a>
        </div>
      </section>

      <section id="about" className="story-section">
        <div className="story-watermark" aria-hidden="true">S</div>
        <div className="story-heading">
          <p className="section-title left">{copy.storyKicker}</p>
          <h2>{copy.storyTitle}</h2>
        </div>
        <div className="story-copy">
          {copy.story.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
        </div>
      </section>

      <section id="fields" className="fields-section">
        <div className="center-heading">
          <p className="section-title">{copy.fieldsKicker}</p>
          <p className="section-intro">{copy.fieldsIntro}</p>
        </div>
        <div className="fields-grid">
          {copy.fields.map((field, index) => (
            <article className="field-card" key={field.title} style={{ backgroundImage: `url(${field.image})` }}>
              <span className="field-number">0{index + 1}</span>
              <div className="field-content">
                <h3>{field.title}</h3>
                <p>{field.body}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="milestones-section">
        <div className="center-heading">
          <p className="section-title">{copy.milestonesKicker}</p>
          <p className="section-intro">{copy.milestonesIntro}</p>
        </div>
        <div className="milestones-grid">
          {copy.milestones.map(([number, title, body]) => (
            <article key={number}>
              <span>{number}</span>
              <h3>{title}</h3>
              <p>{body}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="partner" className="partners-section">
        <p className="section-title">{copy.partnerKicker}</p>
        <div className="partner-lockup">
          <span>{copy.builtWith}</span>
          <img src="/htc-logo.svg" alt="HTC" />
        </div>
      </section>

      <footer id="contact">
        <div className="footer-main">
          <div className="footer-brand">
            <img src="/setco-logo-transparent.png" alt="SETCO" />
          </div>
          <div className="footer-column footer-menu">
            <h3>{copy.footerMenu}</h3>
            {copy.nav.slice(1, 5).map(([label, href], index) => <a key={`${label}-${index}`} href={href}>{label}</a>)}
          </div>
          <div className="footer-column">
            <h3>{copy.footerTouch}</h3>
            <p>{copy.location}</p>
            <p>{copy.enquiries}</p>
          </div>
          <div className="footer-column">
            <h3>{copy.footerSocial}</h3>
            <div className="social-row" aria-label="Social media"><span>in</span><span>◎</span><span>𝕏</span></div>
          </div>
        </div>
        <div className="footer-bottom">© {new Date().getFullYear()} {copy.rights}</div>
      </footer>
    </main>
  );
}
